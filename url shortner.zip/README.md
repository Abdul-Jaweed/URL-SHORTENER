# URL SHORTNER APPLICATION

The URL shortener application is a Flask web application that allows users to enter a long URL and receive a short URL in return. The user can then use the short URL to access the original long URL. The application uses a database to store the original long URL and the corresponding short URL, and retrieves the original URL when a user visits the short URL. The application also includes a feature to copy the short URL to the clipboard.

Web App [Link](https://url-shortener-wgfj.onrender.com/)


### Tech Used

- Python
- VS Code
- Flask
- HTML5
- CSS
- SQLite
- SQLALchemy
_ SQLMigrations

### Infrastructure  Used

- Render
- Render Web Service

